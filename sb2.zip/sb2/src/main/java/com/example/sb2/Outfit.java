package com.example.sb2;

import org.springframework.stereotype.Component;

public interface Outfit {
    public void wear();
}