package com.example.sb1;

public interface Outfit {
    public void wear();
}
