package com.example.sb1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Sb1Application {

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(Sb1Application.class, args);
		Outfit outfit = context.getBean(Outfit.class);
		System.out.println("Output Instance: " + outfit);
		outfit.wear();

		Girl girl = context.getBean(Girl.class);

		System.out.println("Girl Instance: " + girl);

		System.out.println("Girl Outfit: " + girl.outfit);

		girl.outfit.wear();
	}

}
