package com.example.sb4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
