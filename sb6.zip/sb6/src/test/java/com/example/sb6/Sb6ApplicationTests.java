package com.example.sb6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
