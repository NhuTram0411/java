package com.example.sb5;

import org.springframework.stereotype.Component;

@Component
public class Girl {

    @Override
    public String toString() {
        return "Girl.java";
    }
}