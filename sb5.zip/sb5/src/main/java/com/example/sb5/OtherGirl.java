package com.example.sb5;

import org.springframework.stereotype.Component;

@Component
public class OtherGirl {
    @Override
    public String toString() {
        return "OtherGirl.java";
    }
}