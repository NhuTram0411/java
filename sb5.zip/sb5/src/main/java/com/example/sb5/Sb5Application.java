package com.example.sb5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Sb5Application {

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(Sb5Application.class, args);
//		try {
//			Girl girl = context.getBean(Girl.class);
//			System.out.println("Bean: " + girl.toString());
//		} catch (Exception e) {
//			System.out.println("Bean Girl không tồn tại");
//		}
//
//		try {
//			OtherGirl otherGirl = context.getBean(OtherGirl.class);
//			if (otherGirl != null) {
//				System.out.println("Bean: " + otherGirl.toString());
//			}
//		} catch (Exception e) {
//			System.out.println("Bean Girl không tồn tại");
//		}
//
		try {
			Girl girl = context.getBean(Girl.class);
			System.out.println("Bean: " + girl.toString());
		} catch (Exception e) {
			System.out.println("Bean Girl không tồn tại");
		}

		try {
			OtherGirl otherGirl = context.getBean(OtherGirl.class);
			if (otherGirl != null) {
				System.out.println("Bean: " + otherGirl.toString());
			}
		} catch (Exception e) {
			System.out.println("Bean Girl không tồn tại");
		}
	}
}
